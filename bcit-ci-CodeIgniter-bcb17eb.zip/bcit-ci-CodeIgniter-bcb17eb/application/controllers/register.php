<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class register extends CI_Controller {

	
	public function index()
	{
		
        echo "<h1> register </h1>";
	}
}