<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

	
	public function data($data)
	{
		
        echo "<h1>$data</h1>";
        

	}
    public function tampil(){
        $data['judul'] = "Halaman judul";
        $data['deskripsi'] = "ini deskripsi";

       
        $this->load->view('tampil',$data);
    }

}foreach ($query->result() as $row)
{
    echo $row->IDpelanggan "<br/>";
}